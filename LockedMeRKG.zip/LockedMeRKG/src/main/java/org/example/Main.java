package org.example;
import java.awt.*;
import Working.Display;

public class Main {
    public static final String path = "/Users/rajgauta/Desktop/RKG/LockedMeRKG/Files";

    public static void main(String[] args) {
        Display menu = new Display();
        menu.introScreen();
        menu.mainMenu();
    }

}